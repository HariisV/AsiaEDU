-- AlterTable
ALTER TABLE `BankSoalCategory` ADD COLUMN `keterangan` TEXT NULL;
