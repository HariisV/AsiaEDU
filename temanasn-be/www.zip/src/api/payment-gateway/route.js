const express = require('express');

const router = express.Router();

const {
  getMerchantList,
  createPayment,
  callbackPayment,
  get,
} = require('./controller');
const { authenticateUser } = require('#middlewares');

router.get('/merchant-list', getMerchantList);
router.get('/get', authenticateUser, get);
router.post('/create-payment', authenticateUser, createPayment);
router.post('/callback-payment', callbackPayment);

module.exports = router;
