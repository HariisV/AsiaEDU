const express = require('express');

const router = express.Router();

const { update, remove, getSubCategory, insert } = require('./controller');

router.get('/get-subcategory', getSubCategory);
router.post('/insert', insert);
router.patch('/update/:id', update);
router.delete('/remove/:id', remove);

module.exports = router;
